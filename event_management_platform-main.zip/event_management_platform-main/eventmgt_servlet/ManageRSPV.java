package eventmgt_servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ManageRSPV", urlPatterns = {"/ManageRSPV"})
public class ManageRSPV extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession hs = request.getSession();
        String eid = request.getParameter("eid");
        String attendees = request.getParameter("attendees");
        String status = request.getParameter("status");
        
        try {
            if(request.getParameter("addrsvp").equals("Add")){
                DBConnect.insertUpdateQuery("INSERT INTO `rsvp_attendance`(`eid`, `uid`, `attendance_status`, `attendees`) VALUES ("+eid+","+hs.getAttribute("uid")+",'"+status+"',"+attendees+")");
                response.sendRedirect("events.jsp");
            } else if(request.getParameter("addrsvp").equals("Update")){
                DBConnect.insertUpdateQuery("UPDATE `rsvp_attendance` SET `attendance_status`='"+status+"', `attendees`="+attendees+" WHERE eid="+eid+" AND uid="+hs.getAttribute("uid"));
                response.sendRedirect("events.jsp");
            } 
        } catch(Exception e){
            System.out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
