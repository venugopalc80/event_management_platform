package eventmgt_servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import weka.core.Instances;
import weka.core.DenseInstance;
import weka.core.Attribute;
import weka.classifiers.Classifier;
import weka.classifiers.trees.J48;
import weka.core.SerializationHelper;

@WebServlet(name = "EventPredictionServlet", urlPatterns = {"/predictEvent"})
public class EventPredictionServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
                try {
            response.setContentType("text/html;charset=UTF-8");
            HttpSession hs = request.getSession();
            String location = request.getParameter("location");
            String date = request.getParameter("date");
            String description = request.getParameter("description");

            // Load the trained model (you could store the model serialized after training)
            Classifier classifier = (J48) weka.core.SerializationHelper.read("event_model.model");

            // Create the attributes used for prediction (this should match the attributes used in training)
            ArrayList<Attribute> attributes = new ArrayList<>();
            ArrayList<String> eventTypes = new ArrayList<>(Arrays.asList("Workshop", "Wedding", "Party", "Conference"));

            attributes.add(new Attribute("Location"));
            attributes.add(new Attribute("Date"));
            attributes.add(new Attribute("Description"));
            attributes.add(new Attribute("EventType", eventTypes));

            // Create an empty dataset with these attributes (just like the one used during training)
            Instances instances = new Instances("PredictionInstances", attributes, 1);
            instances.setClassIndex(instances.numAttributes() - 1);  // Last attribute is the class (EventType)

            // Create the instance based on user input (make sure it's properly structured)
            double[] values = new double[instances.numAttributes()];

            // For nominal attributes, you should encode them as indices (match them with the eventTypes and location/description values)
            values[0] = location.equals("London") ? 0 : 1; // Location encoding (simplified)
            values[1] = 0; 
            values[2] = description.equals("AI conference with workshops") ? 0 : 1; // Description encoding (simplified)
            values[3] = eventTypes.indexOf("Workshop"); // EventType encoding

            // Create an instance and add it to the dataset
            DenseInstance instance = new DenseInstance(1.0, values);
            instance.setDataset(instances); // Set the dataset for the instance
            instances.add(instance);

            // Predict the event type
            double predictedClassValue = classifier.classifyInstance(instance);
            String predictedEventType = instances.classAttribute().value((int) predictedClassValue);

            // Respond with the prediction
            hs.setAttribute("predict", predictedEventType);
            //response.getWriter().println("Predicted Event Type: " + predictedEventType);
            response.sendRedirect("admin/trainModel.jsp");
        } catch (Exception ex) {
            response.getWriter().println("Error during prediction: " + ex.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
