package eventmgt_servlet;
import java.sql.*;
public class DBConnect {
    public static Connection cn;  

     public static Connection getConnection() throws SQLException, ClassNotFoundException {
        if (cn == null) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost/emma_eventmgt_db","root","");
         }
         return cn;
     }  

    //Creating universal method to close connect will mysql database
    public static void CloseConnection() {
        if (cn != null) {
            try {
                cn.close();
                cn = null;
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    //Creating universal method to query forretriving information
    public static ResultSet getResultFromSqlQuery(String SqlQueryString) {
        //Creating Resultset object
        ResultSet rs = null;
        try {
            //Checking whether the connection is null or null
            if (cn == null) {
                getConnection();
            }
            rs = cn.createStatement().executeQuery(SqlQueryString);
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return rs;
    }

    //Creating universal method to query for inserting or updating information in mysql database
    public static int insertUpdateQuery(String SqlQueryString) {
        int count = 2;
        try {
            if (cn == null) {
                getConnection();
            }
            count = cn.createStatement().executeUpdate(SqlQueryString);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return count;
    }
}
