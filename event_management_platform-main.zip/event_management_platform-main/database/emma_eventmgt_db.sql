-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 15, 2025 at 08:37 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emma_eventmgt_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `aid` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aid`, `username`, `password`) VALUES
(1, 'admin', 'admin@123');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `eid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `location` varchar(150) NOT NULL,
  `detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`eid`, `uid`, `name`, `type`, `date`, `location`, `detail`) VALUES
(1, 1, 'Python Workshop', 'Workshop', '2025-03-28', 'London', 'Python basic concepts'),
(2, 1, 'C# Workshop', 'Workshop', '2025-03-15', 'Manchester', 'Basic concepts'),
(4, 2, 'Viky and Jenisha\'s Wedding', 'Wedding', '2025-03-22', 'Manchester', 'Family Function'),
(6, 5, 'Lisa & Jacob\'s Wedding', 'Wedding', '2025-03-25', 'London', 'Family Function'),
(7, 5, 'Python Workshop', 'Workshop', '2025-03-20', 'Manchester', 'Python Workshop for University students'),
(8, 6, 'C++ Workshop', 'Workshop', '2025-03-21', 'Manchester', 'College students workshop'),
(11, 7, 'Welcome Party', 'Party', '2025-03-24', 'London', 'College students workshop'),
(12, 7, 'Business Meeting', 'Conference', '2025-03-20', 'Manchester', 'Business Meeting');

-- --------------------------------------------------------

--
-- Table structure for table `event_list`
--

CREATE TABLE `event_list` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `event_list`
--

INSERT INTO `event_list` (`id`, `name`) VALUES
(3, 'Conference'),
(2, 'Party'),
(1, 'Wedding'),
(4, 'Workshop');

-- --------------------------------------------------------

--
-- Table structure for table `rsvp_attendance`
--

CREATE TABLE `rsvp_attendance` (
  `rid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `attendance_status` varchar(25) NOT NULL,
  `attendees` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rsvp_attendance`
--

INSERT INTO `rsvp_attendance` (`rid`, `eid`, `uid`, `attendance_status`, `attendees`) VALUES
(1, 1, 1, 'required', 50),
(2, 2, 1, 'required', 100),
(5, 8, 6, 'required', 150),
(8, 12, 7, 'required', 20);

-- --------------------------------------------------------

--
-- Table structure for table `rsvp_attendees_count`
--

CREATE TABLE `rsvp_attendees_count` (
  `id` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rsvp_attendees_count`
--

INSERT INTO `rsvp_attendees_count` (`id`, `eid`, `uid`) VALUES
(1, 1, 2),
(2, 2, 2),
(3, 1, 3),
(4, 2, 3),
(5, 2, 4),
(6, 4, 5),
(7, 7, 6),
(8, 2, 6),
(9, 4, 1),
(10, 8, 1),
(11, 7, 7),
(12, 8, 7),
(13, 6, 7);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `uid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(120) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`uid`, `username`, `email`, `contact`, `password`) VALUES
(1, 'mason', 'mason@gmail.com', '8798655421', '1111'),
(2, 'jerry', 'jerry@gmail.com', '8798655421', '111222'),
(3, 'maria', 'maria@abc.com', '5498875465', '123123'),
(5, 'joseph', 'joseph@gmail.com', '8798546528', '444444'),
(6, 'lilly', 'lilly@gmail.com', '2345654378', '787878'),
(7, 'ethan', 'ethan@gmail.com', '6598875421', '555555');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`eid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `event_list`
--
ALTER TABLE `event_list`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `rsvp_attendance`
--
ALTER TABLE `rsvp_attendance`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `eid` (`eid`);

--
-- Indexes for table `rsvp_attendees_count`
--
ALTER TABLE `rsvp_attendees_count`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`uid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `eid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `event_list`
--
ALTER TABLE `event_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rsvp_attendance`
--
ALTER TABLE `rsvp_attendance`
  MODIFY `rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rsvp_attendees_count`
--
ALTER TABLE `rsvp_attendees_count`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `events`
--
ALTER TABLE `events`
  ADD CONSTRAINT `events_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `events_ibfk_2` FOREIGN KEY (`type`) REFERENCES `event_list` (`name`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `rsvp_attendance`
--
ALTER TABLE `rsvp_attendance`
  ADD CONSTRAINT `rsvp_attendance_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `users` (`uid`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `rsvp_attendance_ibfk_2` FOREIGN KEY (`eid`) REFERENCES `events` (`eid`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
